﻿namespace LarpIT_LX
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ToolBar = new System.Windows.Forms.MenuStrip();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EmailTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.nhcarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NhcarTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.CitrixTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CitrixTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.TimeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.TexasMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.CzechMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.SingaporeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.FollowUpTool = new System.Windows.Forms.ToolStripMenuItem();
            this.LogMeInTool = new System.Windows.Forms.ToolStripMenuItem();
            this.LogMeInLinkTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThemeTool = new System.Windows.Forms.ToolStripMenuItem();
            this.DefaultTool = new System.Windows.Forms.ToolStripMenuItem();
            this.DarkTool = new System.Windows.Forms.ToolStripMenuItem();
            this.ModeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.EmailModeButton = new System.Windows.Forms.ToolStripMenuItem();
            this.CallModeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.DataGroupBox = new System.Windows.Forms.GroupBox();
            this.AssetTextBox = new System.Windows.Forms.TextBox();
            this.AssetLabel = new System.Windows.Forms.Label();
            this.ContactTextBox = new System.Windows.Forms.TextBox();
            this.ContactLabel = new System.Windows.Forms.Label();
            this.LocationTextBox = new System.Windows.Forms.TextBox();
            this.LocationLabel = new System.Windows.Forms.Label();
            this.BadgeTextBox = new System.Windows.Forms.TextBox();
            this.BadgeLabel = new System.Windows.Forms.Label();
            this.VerifyCheckBox = new System.Windows.Forms.CheckBox();
            this.LocalSupportCheckBox = new System.Windows.Forms.CheckBox();
            this.MainIssueGroupBox = new System.Windows.Forms.GroupBox();
            this.MainIssueTextBox = new System.Windows.Forms.TextBox();
            this.WorkNotesGroupBox = new System.Windows.Forms.GroupBox();
            this.RichTextBox = new System.Windows.Forms.RichTextBox();
            this.AutoDetectLocalSupport = new System.Windows.Forms.Timer(this.components);
            this.StopSleep = new System.Windows.Forms.Timer(this.components);
            this.ELabel = new System.Windows.Forms.Label();
            this.AfkLabel = new System.Windows.Forms.Label();
            this.AutoBadge = new System.Windows.Forms.Timer(this.components);
            this.ToolBar.SuspendLayout();
            this.DataGroupBox.SuspendLayout();
            this.MainIssueGroupBox.SuspendLayout();
            this.WorkNotesGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolBar
            // 
            this.ToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolsToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.ModeMenu});
            this.ToolBar.Location = new System.Drawing.Point(0, 0);
            this.ToolBar.Name = "ToolBar";
            this.ToolBar.Size = new System.Drawing.Size(330, 24);
            this.ToolBar.TabIndex = 0;
            this.ToolBar.Text = "menuStrip1";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.emailToolStripMenuItem,
            this.nhcarToolStripMenuItem,
            this.CitrixTool,
            this.TimeMenu,
            this.FollowUpTool,
            this.LogMeInTool});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // emailToolStripMenuItem
            // 
            this.emailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EmailTextBox});
            this.emailToolStripMenuItem.Name = "emailToolStripMenuItem";
            this.emailToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.emailToolStripMenuItem.Text = "&Email";
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(100, 23);
            this.EmailTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EmailTextBox_KeyDown);
            // 
            // nhcarToolStripMenuItem
            // 
            this.nhcarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NhcarTextBox});
            this.nhcarToolStripMenuItem.Name = "nhcarToolStripMenuItem";
            this.nhcarToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.nhcarToolStripMenuItem.Text = "&Nhcar";
            // 
            // NhcarTextBox
            // 
            this.NhcarTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NhcarTextBox.Name = "NhcarTextBox";
            this.NhcarTextBox.Size = new System.Drawing.Size(100, 23);
            this.NhcarTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NhcarTextBox_KeyDown);
            // 
            // CitrixTool
            // 
            this.CitrixTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CitrixTextBox});
            this.CitrixTool.Name = "CitrixTool";
            this.CitrixTool.Size = new System.Drawing.Size(165, 22);
            this.CitrixTool.Text = "&Citrix";
            // 
            // CitrixTextBox
            // 
            this.CitrixTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CitrixTextBox.Name = "CitrixTextBox";
            this.CitrixTextBox.Size = new System.Drawing.Size(100, 23);
            this.CitrixTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CitrixTextBox_KeyDown);
            // 
            // TimeMenu
            // 
            this.TimeMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TexasMenu,
            this.CzechMenu,
            this.SingaporeMenu});
            this.TimeMenu.Name = "TimeMenu";
            this.TimeMenu.Size = new System.Drawing.Size(165, 22);
            this.TimeMenu.Text = "&Times";
            // 
            // TexasMenu
            // 
            this.TexasMenu.Name = "TexasMenu";
            this.TexasMenu.Size = new System.Drawing.Size(155, 22);
            this.TexasMenu.Text = "&Texas";
            this.TexasMenu.Click += new System.EventHandler(this.TexasMenu_Click);
            // 
            // CzechMenu
            // 
            this.CzechMenu.Name = "CzechMenu";
            this.CzechMenu.Size = new System.Drawing.Size(155, 22);
            this.CzechMenu.Text = "&Czech Republic";
            this.CzechMenu.Click += new System.EventHandler(this.CzechMenu_Click);
            // 
            // SingaporeMenu
            // 
            this.SingaporeMenu.Name = "SingaporeMenu";
            this.SingaporeMenu.Size = new System.Drawing.Size(155, 22);
            this.SingaporeMenu.Text = "&Singapore";
            this.SingaporeMenu.Click += new System.EventHandler(this.SingaporeMenu_Click);
            // 
            // FollowUpTool
            // 
            this.FollowUpTool.Name = "FollowUpTool";
            this.FollowUpTool.Size = new System.Drawing.Size(165, 22);
            this.FollowUpTool.Text = "&Follow Up";
            this.FollowUpTool.Click += new System.EventHandler(this.FollowUpTool_Click);
            // 
            // LogMeInTool
            // 
            this.LogMeInTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LogMeInLinkTextBox});
            this.LogMeInTool.Name = "LogMeInTool";
            this.LogMeInTool.Size = new System.Drawing.Size(165, 22);
            this.LogMeInTool.Text = "&LogMeIn";
            // 
            // LogMeInLinkTextBox
            // 
            this.LogMeInLinkTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LogMeInLinkTextBox.Name = "LogMeInLinkTextBox";
            this.LogMeInLinkTextBox.Size = new System.Drawing.Size(100, 23);
            this.LogMeInLinkTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LogMeInLinkTextBox_KeyDown);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ThemeTool});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "&Settings";
            // 
            // ThemeTool
            // 
            this.ThemeTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DefaultTool,
            this.DarkTool});
            this.ThemeTool.Name = "ThemeTool";
            this.ThemeTool.Size = new System.Drawing.Size(110, 22);
            this.ThemeTool.Text = "&Theme";
            // 
            // DefaultTool
            // 
            this.DefaultTool.Name = "DefaultTool";
            this.DefaultTool.Size = new System.Drawing.Size(112, 22);
            this.DefaultTool.Text = "&Default";
            this.DefaultTool.Click += new System.EventHandler(this.DefaultTool_Click);
            // 
            // DarkTool
            // 
            this.DarkTool.Name = "DarkTool";
            this.DarkTool.Size = new System.Drawing.Size(112, 22);
            this.DarkTool.Text = "&Dark";
            this.DarkTool.Click += new System.EventHandler(this.DarkTool_Click);
            // 
            // ModeMenu
            // 
            this.ModeMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EmailModeButton,
            this.CallModeMenu});
            this.ModeMenu.Name = "ModeMenu";
            this.ModeMenu.Size = new System.Drawing.Size(50, 20);
            this.ModeMenu.Text = "&Mode";
            // 
            // EmailModeButton
            // 
            this.EmailModeButton.ForeColor = System.Drawing.Color.Black;
            this.EmailModeButton.Name = "EmailModeButton";
            this.EmailModeButton.Size = new System.Drawing.Size(152, 22);
            this.EmailModeButton.Text = "Email";
            this.EmailModeButton.Click += new System.EventHandler(this.EmailModeButton_Click);
            // 
            // CallModeMenu
            // 
            this.CallModeMenu.ForeColor = System.Drawing.Color.Black;
            this.CallModeMenu.Name = "CallModeMenu";
            this.CallModeMenu.Size = new System.Drawing.Size(152, 22);
            this.CallModeMenu.Text = "&Call";
            this.CallModeMenu.Click += new System.EventHandler(this.CallModeMenu_Click);
            // 
            // DataGroupBox
            // 
            this.DataGroupBox.Controls.Add(this.AssetTextBox);
            this.DataGroupBox.Controls.Add(this.AssetLabel);
            this.DataGroupBox.Controls.Add(this.ContactTextBox);
            this.DataGroupBox.Controls.Add(this.ContactLabel);
            this.DataGroupBox.Controls.Add(this.LocationTextBox);
            this.DataGroupBox.Controls.Add(this.LocationLabel);
            this.DataGroupBox.Controls.Add(this.BadgeTextBox);
            this.DataGroupBox.Controls.Add(this.BadgeLabel);
            this.DataGroupBox.ForeColor = System.Drawing.Color.Red;
            this.DataGroupBox.Location = new System.Drawing.Point(12, 36);
            this.DataGroupBox.Name = "DataGroupBox";
            this.DataGroupBox.Size = new System.Drawing.Size(306, 145);
            this.DataGroupBox.TabIndex = 1;
            this.DataGroupBox.TabStop = false;
            this.DataGroupBox.Text = "LarpIT Data";
            // 
            // AssetTextBox
            // 
            this.AssetTextBox.Location = new System.Drawing.Point(122, 109);
            this.AssetTextBox.Name = "AssetTextBox";
            this.AssetTextBox.Size = new System.Drawing.Size(167, 22);
            this.AssetTextBox.TabIndex = 7;
            this.AssetTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.AssetTextBox_MouseClick);
            // 
            // AssetLabel
            // 
            this.AssetLabel.AutoSize = true;
            this.AssetLabel.Location = new System.Drawing.Point(18, 112);
            this.AssetLabel.Name = "AssetLabel";
            this.AssetLabel.Size = new System.Drawing.Size(37, 13);
            this.AssetLabel.TabIndex = 6;
            this.AssetLabel.Text = "Asset:";
            // 
            // ContactTextBox
            // 
            this.ContactTextBox.Location = new System.Drawing.Point(122, 81);
            this.ContactTextBox.Name = "ContactTextBox";
            this.ContactTextBox.Size = new System.Drawing.Size(167, 22);
            this.ContactTextBox.TabIndex = 5;
            this.ContactTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ContactTextBox_MouseClick);
            // 
            // ContactLabel
            // 
            this.ContactLabel.AutoSize = true;
            this.ContactLabel.Location = new System.Drawing.Point(18, 84);
            this.ContactLabel.Name = "ContactLabel";
            this.ContactLabel.Size = new System.Drawing.Size(50, 13);
            this.ContactLabel.TabIndex = 4;
            this.ContactLabel.Text = "Contact:";
            // 
            // LocationTextBox
            // 
            this.LocationTextBox.Location = new System.Drawing.Point(122, 53);
            this.LocationTextBox.Name = "LocationTextBox";
            this.LocationTextBox.Size = new System.Drawing.Size(167, 22);
            this.LocationTextBox.TabIndex = 3;
            this.LocationTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LocationTextBox_MouseClick);
            // 
            // LocationLabel
            // 
            this.LocationLabel.AutoSize = true;
            this.LocationLabel.Location = new System.Drawing.Point(18, 56);
            this.LocationLabel.Name = "LocationLabel";
            this.LocationLabel.Size = new System.Drawing.Size(54, 13);
            this.LocationLabel.TabIndex = 2;
            this.LocationLabel.Text = "Location:";
            // 
            // BadgeTextBox
            // 
            this.BadgeTextBox.Location = new System.Drawing.Point(122, 25);
            this.BadgeTextBox.Name = "BadgeTextBox";
            this.BadgeTextBox.Size = new System.Drawing.Size(167, 22);
            this.BadgeTextBox.TabIndex = 1;
            this.BadgeTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BadgeTextBox_MouseClick);
            this.BadgeTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BadgeTextBox_KeyDown);
            // 
            // BadgeLabel
            // 
            this.BadgeLabel.AutoSize = true;
            this.BadgeLabel.Location = new System.Drawing.Point(18, 28);
            this.BadgeLabel.Name = "BadgeLabel";
            this.BadgeLabel.Size = new System.Drawing.Size(81, 13);
            this.BadgeLabel.TabIndex = 0;
            this.BadgeLabel.Text = "Badge/Cws ID:";
            // 
            // VerifyCheckBox
            // 
            this.VerifyCheckBox.AutoSize = true;
            this.VerifyCheckBox.ForeColor = System.Drawing.Color.Red;
            this.VerifyCheckBox.Location = new System.Drawing.Point(12, 187);
            this.VerifyCheckBox.Name = "VerifyCheckBox";
            this.VerifyCheckBox.Size = new System.Drawing.Size(70, 17);
            this.VerifyCheckBox.TabIndex = 2;
            this.VerifyCheckBox.Text = "Verified?";
            this.VerifyCheckBox.UseVisualStyleBackColor = true;
            // 
            // LocalSupportCheckBox
            // 
            this.LocalSupportCheckBox.AutoSize = true;
            this.LocalSupportCheckBox.ForeColor = System.Drawing.Color.Red;
            this.LocalSupportCheckBox.Location = new System.Drawing.Point(97, 187);
            this.LocalSupportCheckBox.Name = "LocalSupportCheckBox";
            this.LocalSupportCheckBox.Size = new System.Drawing.Size(102, 17);
            this.LocalSupportCheckBox.TabIndex = 3;
            this.LocalSupportCheckBox.Text = "Local Support?";
            this.LocalSupportCheckBox.UseVisualStyleBackColor = true;
            // 
            // MainIssueGroupBox
            // 
            this.MainIssueGroupBox.Controls.Add(this.MainIssueTextBox);
            this.MainIssueGroupBox.ForeColor = System.Drawing.Color.Red;
            this.MainIssueGroupBox.Location = new System.Drawing.Point(12, 210);
            this.MainIssueGroupBox.Name = "MainIssueGroupBox";
            this.MainIssueGroupBox.Size = new System.Drawing.Size(306, 60);
            this.MainIssueGroupBox.TabIndex = 4;
            this.MainIssueGroupBox.TabStop = false;
            this.MainIssueGroupBox.Text = "Main Issue";
            // 
            // MainIssueTextBox
            // 
            this.MainIssueTextBox.AutoCompleteCustomSource.AddRange(new string[] {
            "domain password reset",
            "Domain Password Reset",
            "windows password reset",
            "Windows Password Reset",
            "cws password reset",
            "Cws Password Reset",
            "baan password reset",
            "Baan Password Reset",
            "register new device with vip access",
            "Register New Device with VIP Access",
            "defendpoint code",
            "defend point code",
            "DefendPoint Code",
            "Defend Point Code",
            "barista chat disconnect",
            "Barista Chat Disconnect",
            "bitlocker recovery key",
            "Bitlocker Recovery Key"});
            this.MainIssueTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.MainIssueTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.MainIssueTextBox.Location = new System.Drawing.Point(21, 21);
            this.MainIssueTextBox.Name = "MainIssueTextBox";
            this.MainIssueTextBox.Size = new System.Drawing.Size(268, 22);
            this.MainIssueTextBox.TabIndex = 8;
            this.MainIssueTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MainIssueTextBox_MouseClick);
            // 
            // WorkNotesGroupBox
            // 
            this.WorkNotesGroupBox.Controls.Add(this.RichTextBox);
            this.WorkNotesGroupBox.ForeColor = System.Drawing.Color.Red;
            this.WorkNotesGroupBox.Location = new System.Drawing.Point(12, 276);
            this.WorkNotesGroupBox.Name = "WorkNotesGroupBox";
            this.WorkNotesGroupBox.Size = new System.Drawing.Size(306, 150);
            this.WorkNotesGroupBox.TabIndex = 5;
            this.WorkNotesGroupBox.TabStop = false;
            this.WorkNotesGroupBox.Text = "Work Notes";
            // 
            // RichTextBox
            // 
            this.RichTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RichTextBox.Location = new System.Drawing.Point(6, 21);
            this.RichTextBox.Name = "RichTextBox";
            this.RichTextBox.Size = new System.Drawing.Size(294, 123);
            this.RichTextBox.TabIndex = 6;
            this.RichTextBox.Text = "";
            this.RichTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.RichTextBox_MouseClick);
            this.RichTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RichTextBox_KeyDown);
            // 
            // AutoDetectLocalSupport
            // 
            this.AutoDetectLocalSupport.Enabled = true;
            this.AutoDetectLocalSupport.Interval = 1000;
            this.AutoDetectLocalSupport.Tick += new System.EventHandler(this.AutoDetectLocalSupport_Tick);
            // 
            // StopSleep
            // 
            this.StopSleep.Interval = 480000;
            this.StopSleep.Tick += new System.EventHandler(this.StopSleep_Tick);
            // 
            // ELabel
            // 
            this.ELabel.AutoSize = true;
            this.ELabel.ForeColor = System.Drawing.Color.Red;
            this.ELabel.Location = new System.Drawing.Point(247, 184);
            this.ELabel.Name = "ELabel";
            this.ELabel.Size = new System.Drawing.Size(77, 13);
            this.ELabel.TabIndex = 6;
            this.ELabel.Text = "Emode = OFF";
            // 
            // AfkLabel
            // 
            this.AfkLabel.AutoSize = true;
            this.AfkLabel.ForeColor = System.Drawing.Color.Red;
            this.AfkLabel.Location = new System.Drawing.Point(263, 197);
            this.AfkLabel.Name = "AfkLabel";
            this.AfkLabel.Size = new System.Drawing.Size(61, 13);
            this.AfkLabel.TabIndex = 7;
            this.AfkLabel.Text = "AFK = OFF";
            // 
            // AutoBadge
            // 
            this.AutoBadge.Enabled = true;
            this.AutoBadge.Tick += new System.EventHandler(this.AutoBadge_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(330, 438);
            this.Controls.Add(this.AfkLabel);
            this.Controls.Add(this.ELabel);
            this.Controls.Add(this.WorkNotesGroupBox);
            this.Controls.Add(this.MainIssueGroupBox);
            this.Controls.Add(this.LocalSupportCheckBox);
            this.Controls.Add(this.VerifyCheckBox);
            this.Controls.Add(this.DataGroupBox);
            this.Controls.Add(this.ToolBar);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.MainMenuStrip = this.ToolBar;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LarpIT LX";
            this.TopMost = true;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.ToolBar.ResumeLayout(false);
            this.ToolBar.PerformLayout();
            this.DataGroupBox.ResumeLayout(false);
            this.DataGroupBox.PerformLayout();
            this.MainIssueGroupBox.ResumeLayout(false);
            this.MainIssueGroupBox.PerformLayout();
            this.WorkNotesGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip ToolBar;
        private System.Windows.Forms.GroupBox DataGroupBox;
        private System.Windows.Forms.TextBox BadgeTextBox;
        private System.Windows.Forms.Label BadgeLabel;
        private System.Windows.Forms.TextBox AssetTextBox;
        private System.Windows.Forms.Label AssetLabel;
        private System.Windows.Forms.TextBox ContactTextBox;
        private System.Windows.Forms.Label ContactLabel;
        private System.Windows.Forms.TextBox LocationTextBox;
        private System.Windows.Forms.Label LocationLabel;
        private System.Windows.Forms.CheckBox VerifyCheckBox;
        private System.Windows.Forms.CheckBox LocalSupportCheckBox;
        private System.Windows.Forms.GroupBox MainIssueGroupBox;
        private System.Windows.Forms.TextBox MainIssueTextBox;
        private System.Windows.Forms.GroupBox WorkNotesGroupBox;
        private System.Windows.Forms.RichTextBox RichTextBox;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ThemeTool;
        private System.Windows.Forms.ToolStripMenuItem DefaultTool;
        private System.Windows.Forms.ToolStripMenuItem DarkTool;
        private System.Windows.Forms.ToolStripMenuItem nhcarToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox NhcarTextBox;
        private System.Windows.Forms.ToolStripMenuItem CitrixTool;
        private System.Windows.Forms.ToolStripTextBox CitrixTextBox;
        private System.Windows.Forms.ToolStripMenuItem emailToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox EmailTextBox;
        public System.Windows.Forms.Timer AutoDetectLocalSupport;
        private System.Windows.Forms.ToolStripMenuItem ModeMenu;
        private System.Windows.Forms.ToolStripMenuItem EmailModeButton;
        private System.Windows.Forms.ToolStripMenuItem CallModeMenu;
        public System.Windows.Forms.Timer StopSleep;
        private System.Windows.Forms.Label ELabel;
        private System.Windows.Forms.Label AfkLabel;
        public System.Windows.Forms.Timer AutoBadge;
        private System.Windows.Forms.ToolStripMenuItem FollowUpTool;
        private System.Windows.Forms.ToolStripMenuItem LogMeInTool;
        private System.Windows.Forms.ToolStripTextBox LogMeInLinkTextBox;
        private System.Windows.Forms.ToolStripMenuItem TimeMenu;
        private System.Windows.Forms.ToolStripMenuItem TexasMenu;
        private System.Windows.Forms.ToolStripMenuItem CzechMenu;
        private System.Windows.Forms.ToolStripMenuItem SingaporeMenu;
    }
}

